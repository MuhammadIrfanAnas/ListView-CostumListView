package com.example.prakteklistview;

public class Movie {
    private String Title;
    private String Movie;

    public Movie(String title, String movie) {
        Title = title;
        Movie = movie;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public String getMovie() {
        return Movie;
    }

    public void setMovie(String movie) {
        Movie = movie;
    }
}
